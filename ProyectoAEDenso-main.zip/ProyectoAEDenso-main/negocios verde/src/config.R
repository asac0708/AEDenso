library(readxl)
library(ggplot2)

getwd()
setwd("C:/Users/sofia/Documents/Hackaton Datos/negocios verde/src/")
